// Tombstone 2.0 SETTINGS
//

#define TOMBSTONE_PERK_COST					    2000
#define TOMBSTONE_PERK_BOTTLE_WEAPON			"zombie_perk_bottle_tombstone"
#define TOMBSTONE_SHADER						"specialty_tombstone_zombies"
#define TOMBSTONE_PERK_INFO_STRING              "Hold ^3[{+activate}]^7 for Tombstone 2.0 [Cost: &&1] \n ^8 (Solo) Saves 3 random perks after reviving from Quick Revive. \n (Co-op) Keep perks after being revived. Drops a tombstone power-up on bleed out that saves items and perks."
#define TOMBSTONE_MACHINE_DISABLED_MODEL		"zombie_vending_tombstone"
#define TOMBSTONE_MACHINE_ACTIVE_MODEL			"zombie_vending_tombstone"
#define TOMBSTONE_RADIANT_MACHINE_NAME			"vending_tombstone"
#define TOMBSTONE_MACHINE_LIGHT_FX				"tombstone_light"
#define TOMBSTONE_LIGHTING_FX                   "spiki/perks/fx_machine_tombstone"
#define TOMBSTONE_PERK_STRING					"tombstone_perk"
#define TOMBSTONE_MUS_STING					    "mus_perks_tombstone_sting"
#define TOMBSTONE_MUS_JINGLE					"mus_perks_tombstone_jingle"