#using scripts\codescripts\struct;

#using scripts\shared\array_shared;
#using scripts\shared\clientfield_shared;
#using scripts\shared\system_shared;
#using scripts\shared\util_shared;
#using scripts\shared\visionset_mgr_shared;
#using scripts\shared\callbacks_shared;

#insert scripts\shared\shared.gsh;
#insert scripts\shared\version.gsh;

#using scripts\zm\_util;
#using scripts\zm\_zm_perks;
#using scripts\zm\_zm_pers_upgrades;
#using scripts\zm\_zm_pers_upgrades_functions;
#using scripts\zm\_zm_pers_upgrades_system;
#using scripts\zm\_zm_stats;
#using scripts\zm\_zm_utility;

#using scripts\zm\gametypes\_globallogic_score;

#insert scripts\zm\_zm_perk_tombstone.gsh;
#insert scripts\zm\_zm_perks.gsh;
#insert scripts\zm\_zm_utility.gsh;

#precache( "material", TOMBSTONE_SHADER );
#precache( "string", TOMBSTONE_PERK_INFO_STRING );
#precache( "fx", TOMBSTONE_LIGHTING_FX );

#namespace zm_perk_tombstone;

REGISTER_SYSTEM( "zm_perk_tombstone", &__init__, undefined )

// TOMBSTONE

//-----------------------------------------------------------------------------------
// setup
//-----------------------------------------------------------------------------------
function __init__()
{
	enable_tombstone_perk_for_level();
	callback::on_spawned(&register_player_stats);
}

function enable_tombstone_perk_for_level()
{	
	// register tombstone perk for level
	zm_perks::register_perk_basic_info( PERK_TOMBSTONE, "tombstone", TOMBSTONE_PERK_COST, TOMBSTONE_PERK_INFO_STRING, GetWeapon( TOMBSTONE_PERK_BOTTLE_WEAPON ) );
	zm_perks::register_perk_precache_func( PERK_TOMBSTONE, &tombstone_precache );
	zm_perks::register_perk_clientfields( PERK_TOMBSTONE, &tombstone_register_clientfield, &tombstone_set_clientfield );
	zm_perks::register_perk_machine( PERK_TOMBSTONE, &tombstone_perk_machine_setup );
	zm_perks::register_perk_threads( PERK_TOMBSTONE, &give_tomb_perk, &take_tomb_perk );
	zm_perks::register_perk_host_migration_params( PERK_TOMBSTONE, TOMBSTONE_RADIANT_MACHINE_NAME, TOMBSTONE_MACHINE_LIGHT_FX );
}

function tombstone_precache()
{
	if( IsDefined(level.tombstone_precache_override_func) )
	{
		[[ level.tombstone_precache_override_func ]]();
		return;
	}
	
	level._effect[TOMBSTONE_MACHINE_LIGHT_FX] = TOMBSTONE_LIGHTING_FX;
	
	level.machine_assets[PERK_TOMBSTONE] = SpawnStruct();
	level.machine_assets[PERK_TOMBSTONE].weapon = GetWeapon( TOMBSTONE_PERK_BOTTLE_WEAPON );
	level.machine_assets[PERK_TOMBSTONE].off_model = TOMBSTONE_MACHINE_DISABLED_MODEL;
	level.machine_assets[PERK_TOMBSTONE].on_model = TOMBSTONE_MACHINE_ACTIVE_MODEL;
}

function tombstone_register_clientfield()
{
	clientfield::register( "clientuimodel", PERK_CLIENTFIELD_TOMBSTONE, VERSION_SHIP, 2, "int" );
}

function tombstone_set_clientfield( state )
{
	self clientfield::set_player_uimodel( PERK_CLIENTFIELD_TOMBSTONE, state );
}

function tombstone_perk_machine_setup( use_trigger, perk_machine, bump_trigger, collision )
{
	use_trigger.script_sound = TOMBSTONE_MUS_JINGLE;
	use_trigger.script_string = TOMBSTONE_PERK_STRING;
	use_trigger.script_label = TOMBSTONE_MUS_STING;
	use_trigger.target = TOMBSTONE_RADIANT_MACHINE_NAME;
	perk_machine.script_string = TOMBSTONE_PERK_STRING;
	perk_machine.targetname = TOMBSTONE_RADIANT_MACHINE_NAME;
	if( IsDefined( bump_trigger ) )
	{
		bump_trigger.script_string = TOMBSTONE_PERK_STRING;
	}
}

function give_tomb_perk() {
	IPrintLnBold("TOMBSTONE: OBTAINED");

	self notify(PERK_TOMBSTONE + "_start");
}

function take_tomb_perk( b_pause, str_perk, str_result ) {
	IPrintLnBold("TOMBSTONE: LOST");

	self notify(PERK_TOMBSTONE + "_stop");
}

function register_player_stats()
{
	self globallogic_score::initPersStat(PERK_TOMBSTONE + "_drank", false );
}